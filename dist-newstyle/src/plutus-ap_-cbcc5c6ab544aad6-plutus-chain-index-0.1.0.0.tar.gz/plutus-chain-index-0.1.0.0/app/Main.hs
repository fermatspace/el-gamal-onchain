module Main where

import Plutus.ChainIndex.App qualified as App

main :: IO ()
main = App.main

